package com.engim.verificapratica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VerificaPraticaApplicationTests {

    @Test
    void contextLoads() {
    }

}
