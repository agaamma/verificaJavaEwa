package com.engim.verificapratica;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SorteggiaPartite {

    private List<Squadra> squadre = new ArrayList<>();

    //ES4 controlla se il numero di squadre aggiunte è una potenza di 2.

    public List <Squadra> SquadraPerPartita (){
        double result = Math.sqrt(squadre.size());
        if(result == 2){
            System.out.println("il numero di squadre aggiunte è una potenza di 2");
            while ()
            List<Squadra> ListaPartite = new ArrayList<>();
            ListaPartite.add()
        }
        else
            throw new IndexOutOfBoundsException("RuntimeException");

    }

}
