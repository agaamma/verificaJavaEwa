package com.engim.verificapratica;

public class Partita {
    public Squadra squadre;

}
